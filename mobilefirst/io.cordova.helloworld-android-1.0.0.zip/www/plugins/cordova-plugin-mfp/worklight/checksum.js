var WL_CHECKSUM = {"checksum":717675582,"date":1509026767136,"machine":"Mavericks"}
/* Date: Thu Oct 26 2017 21:06:07 GMT+0700 (WIB) */